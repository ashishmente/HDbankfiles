import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.*;
import java.io.*;
import javax.net.ssl.*;
import java.security.SecureRandom;
import java.text.*;
import org.apache.camel.Exchange;

/**
 * 
 * @author SandipanP
 *
 */

public class sendODE 
{

	public void sendTranODE (Exchange exchange) 
	{
		
		String request = exchange.getIn().getBody();
		//System.out.println(request);
		
		String response = null;
		Socket socket = new Socket();
		
		DataOutputStream os = null;
		DataInputStream is = null;
	
		int tmp = (int) ( Math.random() * 2 + 1);
		
		String host = null;
		int port = 5018, socketTimeout=250;

		if (tmp == 1)
		{
			host = "lqp2apsasode01";
			try {
				socket = new Socket(host,port);
				socket.setSoTimeout(socketTimeout);
			} catch (IOException e) { System.err.println("Couldn't establish Socket connection"); }

			if(socket.isConnected())
			{	
				try {
					os = new DataOutputStream(socket.getOutputStream());
					is = new DataInputStream(socket.getInputStream());
				} catch (IOException e) { System.err.println("Cannot create input/output stream"); }	
				
			}
			else
			{
				host = "lqp2apsasode02";
				try {
					socket = new Socket(host,port);
					socket.setSoTimeout(socketTimeout);
				} catch (IOException e) { System.err.println("Couldn't establish Socket connection"); }
				try {
					os = new DataOutputStream(socket.getOutputStream());
					is = new DataInputStream(socket.getInputStream());
				} catch (IOException e) { System.err.println("Cannot create input/output stream"); }	
			}
		}
		else
		{
			host = "lqp2apsasode02";
			try {
				socket = new Socket(host,port);
				socket.setSoTimeout(socketTimeout);
			} catch (IOException e) { System.err.println("Couldn't establish Socket connection"); }

			if(socket.isConnected())
			{	
				try {
					os = new DataOutputStream(socket.getOutputStream());
					is = new DataInputStream(socket.getInputStream());
				} catch (IOException e) { System.err.println("Cannot create input/output stream"); }	
				
			}
			else
			{
				host = "lqp2apsasode01";
				try {
					socket = new Socket(host,port);
					socket.setSoTimeout(socketTimeout);
				} catch (IOException e) { System.err.println("Couldn't establish Socket connection"); }
				try {
					os = new DataOutputStream(socket.getOutputStream());
					is = new DataInputStream(socket.getInputStream());
				} catch (IOException e) { System.err.println("Cannot create input/output stream"); }	
			}
		}
		
		if (socket != null && os != null && is != null) 
		{
			try 
			{
				//System.out.println("Reading response");
				os.writeUTF(request);
			} catch (IOException e) { System.err.println("Unable to send Request" + e); }

			try 
			{
				response = is.readUTF();
				//System.out.println("echo: " + response);
			} catch (EOFException e) { System.err.println("EOF Exception from ODE" + e); }
			catch (IOException e) { System.err.println("Reading Response from ODE" + e); }
			
			try 
			{
				os.close();
				is.close();
				socket.close();
			} catch (IOException e) { System.err.println("Closing the connections" +e); }
			exchange.getOut().setBody(response);
		}
	}

}
