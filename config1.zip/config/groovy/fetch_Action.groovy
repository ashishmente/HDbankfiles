/*import org.apache.camel.Exchange;
import org.json.JSONObject;

public class ActionExtractorProcessor  {

    
    public void process(Exchange exchange) throws Exception {
        // Get the body, assuming it's a raw JSON string
        String jsonBody = exchange.getIn().getBody(String.class);
        
        try {
            // Convert the JSON string into a JSONObject
            JSONObject jsonObject = new JSONObject(jsonBody);
            
            // Extract the 'Action' field from the 'Data' object
            JSONObject dataObject = jsonObject.getJSONObject("Data");
            String action = dataObject.optString("Action","");
            
            // Set the 'Action' field in the header
            exchange.getIn().setHeader("Action", action);
            
        } catch (Exception e) {
            // Handle errors like missing fields, JSON parsing issues
            exchange.getIn().setHeader("Action", null);
            System.out.println("Error extracting Action field: " + e.getMessage());
        }
    }
}*/

import org.apache.camel.Exchange;
import org.json.JSONObject;

public class ActionExtractorProcessor  {

    
    public void process(Exchange exchange) throws Exception {
        // Get the body, assuming it's a raw JSON string
        String jsonBody = exchange.getIn().getBody(String.class);
        
        try {
            // Convert the JSON string into a JSONObject
            JSONObject jsonObject = new JSONObject(jsonBody);
            
            // Extract the 'Action' field from the 'Data' object
            JSONObject dataObject = jsonObject.getJSONObject("Data");
            String action = dataObject.optString("Action","");
            String CustomerId = dataObject.optString("CustomerId","");
	    String EFMSChannelReferenceNumber = dataObject.optString("EFMSChannelReferenceNumber","");
	    String TransactionCode = dataObject.optString("TransactionCode","");
            // Set the 'Action' field in the header
            exchange.getIn().setHeader("Action", action);
       	exchange.getIn().setHeader("CustomerId", CustomerId);
            exchange.getIn().setHeader("EFMSChannelReferenceNumber", EFMSChannelReferenceNumber);
	exchange.getIn().setHeader("TransactionCode",TransactionCode);
			
			
        } catch (Exception e) {
            // Handle errors like missing fields, JSON parsing issues
            exchange.getIn().setHeader("Action", null);
            System.out.println("Error extracting Action field: " + e.getMessage());
        }
    }
}