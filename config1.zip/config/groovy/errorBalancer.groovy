import org.apache.camel.Exchange;
import java.util.UUID;

public class ServiceUnavailableErrorHandler {

    // Method to generate the 503 error response
    public void process(Exchange exchange) {
        // Generate a unique ID for the error
        String id = UUID.randomUUID().toString();
//	String url = exchange.getIn().getHeader("url");
//	String path = exchange.getIn().getHeader("path");
        // Construct the error response
        String errorResponse = "{\n" +
                "    \"Code\": \"API503\",\n" +
                "    \"Id\": \"" + id + "\",\n" +
                "    \"Message\": \"Service Unavailable\",\n" +
                "    \"Errors\": [\n" +
                "        {\n" +
                "            \"ErrorCode\": \"503\",\n" +
                "            \"Message\": \"API could not connect to internal TCP/IP service\",\n" +
                "            \"Path\": \"\",\n" +
                "            \"Url\": \"\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";

        // Set the error response in the Exchange body
        exchange.getIn().setBody(errorResponse);
    }
}